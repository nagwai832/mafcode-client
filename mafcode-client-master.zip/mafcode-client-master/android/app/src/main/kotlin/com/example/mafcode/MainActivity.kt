package com.example.mafcode

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
